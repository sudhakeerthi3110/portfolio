import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Code, Database, Globe, Palette } from "lucide-react";

const Skills = () => {
  const skillCategories = [
    {
      icon: Code,
      title: "Programming Languages",
      skills: ["JavaScript", "Python", "Java", "C++", "HTML", "CSS"],
      color: "text-blue-500"
    },
    {
      icon: Globe,
      title: "Web Technologies",
      skills: ["React", "Node.js", "Express", "Bootstrap", "Tailwind CSS"],
      color: "text-green-500"
    },
    {
      icon: Database,
      title: "Data Analytics & Databases",
      skills: ["Python for Data Science", "SQL", "MySQL", "Data Visualization", "Statistical Analysis", "Excel"],
      color: "text-purple-500"
    },
    {
      icon: Palette,
      title: "Tools & Technologies",
      skills: ["Git", "GitHub", "VS Code", "Jupyter Notebook", "R Programming", "Tableau"],
      color: "text-orange-500"
    }
  ];

  return (
    <section id="skills" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-text-gradient bg-clip-text text-transparent">
            Skills & Technologies
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Here are the technologies and skills I've been working with during my academic journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {skillCategories.map((category, index) => (
            <Card 
              key={category.title} 
              className="shadow-card hover:shadow-card-hover transition-all duration-300 group hover:scale-105"
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <category.icon className={`w-6 h-6 ${category.color} mr-3 group-hover:scale-110 transition-transform`} />
                  <h3 className="font-semibold text-sm">{category.title}</h3>
                </div>
                
                <div className="space-y-2">
                  {category.skills.map((skill) => (
                    <Badge 
                      key={skill} 
                      variant="secondary" 
                      className="mr-1 mb-1 text-xs hover:bg-primary hover:text-primary-foreground transition-colors cursor-default"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Learning Section */}
        <div className="mt-16 text-center">
          <Card className="max-w-2xl mx-auto shadow-card">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold mb-4">Currently Learning</h3>
              <p className="text-muted-foreground mb-4">
                I'm always eager to learn new technologies and expand my skill set. Currently exploring:
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge variant="outline" className="border-primary text-primary">Advanced Data Analytics</Badge>
                <Badge variant="outline" className="border-primary text-primary">Machine Learning</Badge>
                <Badge variant="outline" className="border-primary text-primary">Big Data Technologies</Badge>
                <Badge variant="outline" className="border-primary text-primary">Cloud Computing</Badge>
                <Badge variant="outline" className="border-primary text-primary">Business Intelligence</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Skills;