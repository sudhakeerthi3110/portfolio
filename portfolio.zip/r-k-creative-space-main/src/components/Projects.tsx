import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github, Code } from "lucide-react";

const Projects = () => {
  const projects = [
    {
      title: "Forensic Crime Data Analysis",
      description: "A comprehensive Python-based forensic crime data analysis project that leverages visualization and statistical insights to explore crime trends, evidence patterns, and case statuses. Features crime type distribution, case status analysis, evidence frequency, time-series plots, and location hotspot identification to assist law enforcement and forensic teams.",
      technologies: ["Python", "Data Visualization", "Pandas", "Matplotlib", "Statistical Analysis", "Crime Analytics"],
      githubUrl: "https://github.com/sudhakeerthi3110/Forensic-Crime-Data-Analysis-Using-Python",
      liveUrl: null,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=300&fit=crop&crop=center",
    },
    {
      title: "Simple Quote Scraper",
      description: "A beginner-friendly Python web scraper that extracts inspirational quotes and their authors from quotes.toscrape.com using requests and BeautifulSoup libraries. Perfect for learning web scraping, HTML parsing, and data extraction techniques.",
      technologies: ["Python", "Web Scraping", "BeautifulSoup", "Requests", "HTML Parsing", "Data Extraction"],
      githubUrl: "https://github.com/sudhakeerthi3110/Simple-Quote-Scraper-using-Python",
      liveUrl: null,
      image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=500&h=300&fit=crop&crop=center",
    },
    {
      title: "Portfolio Website",
      description: "A responsive personal portfolio website showcasing my skills and projects, built with modern web technologies. Features a clean design, smooth animations, and comprehensive sections highlighting my academic journey and technical expertise.",
      technologies: ["React", "TypeScript", "Tailwind CSS", "Vite", "Responsive Design"],
      githubUrl: "https://github.com/sudhakeerthi3110",
      liveUrl: "#",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&h=300&fit=crop&crop=center",
    }
  ];

  return (
    <section id="projects" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-text-gradient bg-clip-text text-transparent">
            Projects & Work
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Here are some of the projects I've been working on during my studies and personal learning journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {projects.map((project, index) => (
            <Card 
              key={project.title} 
              className="shadow-card hover:shadow-card-hover transition-all duration-300 group overflow-hidden"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {project.technologies.map((tech) => (
                    <Badge 
                      key={tech} 
                      variant="secondary" 
                      className="text-xs"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                    className="flex-1"
                  >
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Github className="w-4 h-4 mr-2" />
                      Code
                    </a>
                  </Button>
                  
                  {project.liveUrl && (
                    <Button
                      variant="default"
                      size="sm"
                      asChild
                      className="flex-1"
                    >
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Live
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="max-w-2xl mx-auto shadow-card">
            <CardContent className="p-8">
              <Code className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-4">More Projects Coming Soon</h3>
              <p className="text-muted-foreground mb-6">
                I'm continuously working on new projects and learning experiences. 
                Check out my GitHub for the latest updates and code repositories.
              </p>
              <Button variant="hero" size="lg" asChild>
                <a
                  href="https://github.com/sudhakeerthi3110"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Github className="w-5 h-5 mr-2" />
                  View GitHub Profile
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Projects;