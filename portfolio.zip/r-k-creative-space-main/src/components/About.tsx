import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, GraduationCap, MapPin, User } from "lucide-react";

const About = () => {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-text-gradient bg-clip-text text-transparent">
            About Me
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get to know more about my background, education, and journey in computer science.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Personal Info Card */}
          <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
            <CardContent className="p-8">
              <div className="flex items-center mb-6">
                <User className="w-6 h-6 text-primary mr-3" />
                <h3 className="text-xl font-semibold">Personal Information</h3>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 text-muted-foreground mr-3" />
                  <div>
                    <p className="text-sm text-muted-foreground">Date of Birth</p>
                    <p className="font-medium">October 31, 2006</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <GraduationCap className="w-5 h-5 text-muted-foreground mr-3" />
                  <div>
                    <p className="text-sm text-muted-foreground">Current Studies</p>
                    <p className="font-medium">BSc Computer Science with Data Analytics</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <MapPin className="w-5 h-5 text-muted-foreground mr-3" />
                  <div>
                    <p className="text-sm text-muted-foreground">Institution</p>
                    <p className="font-medium">Sri RamaKrishna College of Arts and Science</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Bio Card */}
          <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold mb-6">My Journey</h3>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  I'm a passionate BSc Computer Science with Data Analytics student at Sri RamaKrishna College of Arts and Science, 
                  dedicated to exploring the intersection of technology, programming, and data-driven insights.
                </p>
                
                <p className="text-muted-foreground leading-relaxed">
                  My academic journey combines core computer science fundamentals with specialized data analytics skills, 
                  preparing me to tackle modern challenges in data science, machine learning, and software development.
                </p>
                
                <div className="pt-4">
                  <p className="text-sm text-muted-foreground mb-3">Areas of Interest:</p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">Data Analytics</Badge>
                    <Badge variant="secondary">Web Development</Badge>
                    <Badge variant="secondary">Data Science</Badge>
                    <Badge variant="secondary">Programming</Badge>
                    <Badge variant="secondary">Machine Learning</Badge>
                    <Badge variant="secondary">Statistical Analysis</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default About;