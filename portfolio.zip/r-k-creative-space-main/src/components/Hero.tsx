import { Button } from "@/components/ui/button";
import { ChevronDown, Github, Linkedin } from "lucide-react";

const Hero = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen flex items-center justify-center bg-hero-gradient relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>
      
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="animate-fade-in">
          {/* Profile Image */}
          <div className="w-32 h-32 md:w-40 md:h-40 mx-auto mb-8 relative">
            <img
              src="/lovable-uploads/3b63ed8e-f5f4-4679-b9f0-e9f64ce35b82.png"
              alt="Keerthana R"
              className="w-full h-full object-cover rounded-full border-4 border-white/20 shadow-2xl animate-float"
            />
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent to-white/10"></div>
          </div>

          {/* Main Content */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 animate-slide-up">
            Hi, I'm{" "}
            <span className="bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              Keerthana R
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-blue-100 mb-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            BSc Computer Science with Data Analytics Student
          </p>
          
          <p className="text-lg text-blue-200 mb-8 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.4s' }}>
            Sri RamaKrishna College of Arts and Science
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 animate-slide-up" style={{ animationDelay: '0.6s' }}>
            <Button
              variant="glass"
              size="lg"
              onClick={() => scrollToSection('about')}
              className="min-w-32"
            >
              About Me
            </Button>
            <Button
              variant="glass"
              size="lg"
              onClick={() => scrollToSection('contact')}
              className="min-w-32"
            >
              Get In Touch
            </Button>
          </div>

          {/* Social Links */}
          <div className="flex justify-center space-x-6 mb-12 animate-slide-up" style={{ animationDelay: '0.8s' }}>
            <a
              href="https://github.com/sudhakeerthi3110"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
            >
              <Github className="w-6 h-6" />
            </a>
            <a
              href="https://www.linkedin.com/in/keerthana-rajagopalan-208b6a318"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
            >
              <Linkedin className="w-6 h-6" />
            </a>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-6 h-6 text-white/70" />
        </div>
      </div>
    </section>
  );
};

export default Hero;