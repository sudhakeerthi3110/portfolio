import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, MessageCircle, Phone } from "lucide-react";

const Contact = () => {
  const contactMethods = [
    {
      icon: Mail,
      title: "Email",
      description: "keerthanarajagopalan4@gmail.com",
      action: "Send Email",
      href: "mailto:keerthanarajagopalan4@gmail.com",
      color: "text-red-500"
    },
    {
      icon: Phone,
      title: "Phone",
      description: "+91 6369308420",
      action: "Call Now",
      href: "tel:+916369308420",
      color: "text-green-500"
    },
    {
      icon: Linkedin,
      title: "LinkedIn",
      description: "Connect with me professionally",
      action: "Connect",
      href: "https://www.linkedin.com/in/keerthana-rajagopalan-208b6a318",
      color: "text-blue-600"
    },
    {
      icon: Github,
      title: "GitHub",
      description: "Check out my code repositories",
      action: "Follow",
      href: "https://github.com/sudhakeerthi3110",
      color: "text-gray-800"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-text-gradient bg-clip-text text-transparent">
            Get In Touch
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            I'm always open to discussing new opportunities, collaborations, or just having a chat about technology.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Contact Methods */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {contactMethods.map((method) => (
              <Card 
                key={method.title} 
                className="shadow-card hover:shadow-card-hover transition-all duration-300 group hover:scale-105"
              >
                <CardContent className="p-6 text-center">
                  <method.icon className={`w-8 h-8 ${method.color} mx-auto mb-4 group-hover:scale-110 transition-transform`} />
                  <h3 className="font-semibold mb-2">{method.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{method.description}</p>
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    <a
                      href={method.href}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {method.action}
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Contact Card */}
          <Card className="shadow-card">
            <CardContent className="p-8 text-center">
              <MessageCircle className="w-12 h-12 text-primary mx-auto mb-6" />
              <h3 className="text-2xl font-semibold mb-4">Let's Connect!</h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Whether you're a fellow student, potential collaborator, or someone who shares a passion for technology, 
                I'd love to hear from you. Feel free to reach out through any of the channels above.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="hero" size="lg" asChild>
                  <a
                    href="https://www.linkedin.com/in/keerthana-rajagopalan-208b6a318"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Linkedin className="w-5 h-5 mr-2" />
                    Connect on LinkedIn
                  </a>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <a
                    href="https://github.com/sudhakeerthi3110"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Github className="w-5 h-5 mr-2" />
                    View GitHub
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Contact;